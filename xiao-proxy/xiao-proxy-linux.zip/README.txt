# Xiao Proxy - 微设备免流服务

## Quick Start

1. Run: chmod +x start.sh install.sh
2. Run: ./install.sh
3. Run: ./start.sh
4. Open browser: http://localhost:3000 (or custom port from config.json)

## Notes

- Node.js will be auto-detected or auto-installed on first run
- Press Ctrl+C to stop

## Configuration

Edit config.json to customize settings:
- web.enabled: true/false (enable/disable Express server)
- web.port: port number (default: 3000)
- logging.console: true/false (enable/disable console logs)

## Files

- start.sh - Start service
- install.sh - Install dependencies
- server.js, etc. - Source files
- public/ - Web frontend
- config.json - Configuration file
