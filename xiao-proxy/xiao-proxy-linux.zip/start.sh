#!/bin/bash
echo "======================================="
echo "  UART NodeJS Service"
echo "======================================="
echo

# 检测可用的 Node.js：本地 > 全局 > nvm(多路径) > 安装
find_node() {
  # 1) 本地打包的 Node.js
  if [ -f "$(pwd)/node/bin/node" ]; then
    NODE="$(pwd)/node/bin/node"
    echo "[Info] Using local bundled Node.js"
    return 0
  fi

  # 2) 全局 PATH 上的 node
  if command -v node > /dev/null 2>&1; then
    NODE="node"
    echo "[Info] Using global Node.js"
    return 0
  fi

  # 3) 尝试从多个路径加载 nvm（兼容 systemd 以 root 运行时找不到 nvm）
  for nvm_dir in     "${NVM_DIR}"     "${HOME}/.nvm"     "/root/.nvm"     /home/*/.nvm;   do
    if [ -f "${nvm_dir}/nvm.sh" ]; then
      echo "[Info] Found nvm at ${nvm_dir}"
      export NVM_DIR="${nvm_dir}"
      . "${nvm_dir}/nvm.sh"
      if command -v node > /dev/null 2>&1; then
        NODE="node"
        echo "[Info] Using nvm Node.js"
        return 0
      fi
      # nvm 存在但没有默认版本，用最新已安装的
      nvm use default 2>/dev/null || nvm use node 2>/dev/null
      if command -v node > /dev/null 2>&1; then
        NODE="node"
        echo "[Info] Using nvm Node.js (activated)"
        return 0
      fi
    fi
  done

  # 4) 直接扫描 nvm 版本目录，找 node 绝对路径（不依赖 nvm.sh）
  for nvm_base in     "${HOME}/.nvm"     "/root/.nvm"     /home/*/.nvm;   do
    for node_bin in "${nvm_base}"/versions/node/*/bin/node; do
      if [ -x "${node_bin}" ]; then
        NODE="${node_bin}"
        echo "[Info] Using Node.js: ${NODE}"
        return 0
      fi
    done
  done

  # 5) 以上全都失败，安装 nvm + Node.js
  echo "[Info] Node.js not found, installing via nvm..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.8/install.sh | bash
  export NVM_DIR="${HOME}/.nvm"
  if [ -f "${NVM_DIR}/nvm.sh" ]; then
    . "${NVM_DIR}/nvm.sh"
  fi
  nvm install 22
  if command -v node > /dev/null 2>&1; then
    NODE="node"
    echo "[Info] Node.js installed: $($NODE -v)"
    return 0
  fi

  echo "[Error] Cannot find or install Node.js"
  return 1
}

find_node || exit 1

echo "Node.js: $($NODE -v)"
echo

# 读取配置文件中的端口号
PORT=3000
if [ -f "config.json" ]; then
    PORT=$(grep "port" config.json | awk -F":" '{print $2}' | sed 's/,//g' | sed 's/}//g' | tr -d ' ')
fi

echo "[Service] http://localhost:$PORT"
echo "Press Ctrl+C to stop."
echo
$NODE server.js
