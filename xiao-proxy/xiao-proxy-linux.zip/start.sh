#!/bin/bash
echo "======================================="
echo "  UART NodeJS Service"
echo "======================================="
echo

# 检测可用的 Node.js：本地 > 全局 > 安装
find_node() {
  if [ -f "$(pwd)/node/bin/node" ]; then
    NODE="$(pwd)/node/bin/node"
    echo "[Info] Using local bundled Node.js"
    return 0
  fi

  if command -v node > /dev/null 2>&1; then
    NODE="node"
    echo "[Info] Using global Node.js"
    return 0
  fi

  echo "[Info] Node.js not found, installing via nvm..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.8/install.sh | bash
  . "$HOME/.nvm/nvm.sh"
  nvm install 24
  NODE="node"
  echo "[Info] Node.js installed: $($NODE -v)"
  return 0
}

find_node

echo "Node.js: \$($NODE -v)"
echo

# 读取配置文件中的端口号
PORT=3000
if [ -f "config.json" ]; then
    PORT=\$(grep "port" config.json | awk -F":" '{print \$2}' | sed 's/,//g' | sed 's/}//g' | tr -d ' ')
fi

echo "[Service] http://localhost:\$PORT"
echo "Press Ctrl+C to stop."
echo
\$NODE server.js
