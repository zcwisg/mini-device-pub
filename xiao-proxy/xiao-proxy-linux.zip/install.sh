#!/bin/bash
echo "========================================"
echo "  UART NodeJS - Install Dependencies"
echo "========================================"
echo

# 检测可用的 Node.js：本地 > 全局 > nvm(多路径) > 安装
find_node() {
  # 1) 本地打包的 Node.js
  if [ -f "$(pwd)/node/bin/node" ]; then
    NODE="$(pwd)/node/bin/node"
    NPM="$(pwd)/node/bin/npm"
    echo "[Info] Using local bundled Node.js"
    return 0
  fi

  # 2) 全局 PATH 上的 node
  if command -v node > /dev/null 2>&1; then
    NODE="node"
    NPM="npm"
    echo "[Info] Using global Node.js"
    return 0
  fi

  # 3) 尝试从多个路径加载 nvm（兼容 systemd 以 root 运行时找不到 nvm）
  for nvm_dir in     "${NVM_DIR}"     "${HOME}/.nvm"     "/root/.nvm"     /home/*/.nvm;   do
    if [ -f "${nvm_dir}/nvm.sh" ]; then
      echo "[Info] Found nvm at ${nvm_dir}"
      export NVM_DIR="${nvm_dir}"
      . "${nvm_dir}/nvm.sh"
      if command -v node > /dev/null 2>&1; then
        NODE="node"
        NPM="npm"
        echo "[Info] Using nvm Node.js"
        return 0
      fi
      # nvm 存在但没有默认版本，用最新已安装的
      nvm use default 2>/dev/null || nvm use node 2>/dev/null
      if command -v node > /dev/null 2>&1; then
        NODE="node"
        NPM="npm"
        echo "[Info] Using nvm Node.js (activated)"
        return 0
      fi
    fi
  done

  # 4) 直接扫描 nvm 版本目录，找 node 绝对路径（不依赖 nvm.sh）
  for nvm_base in     "${HOME}/.nvm"     "/root/.nvm"     /home/*/.nvm;   do
    for node_bin in "${nvm_base}"/versions/node/*/bin/node; do
      if [ -x "${node_bin}" ]; then
        NODE="${node_bin}"
        NPM="${node_bin%/node}/npm"
        echo "[Info] Using Node.js: ${NODE}"
        return 0
      fi
    done
  done

  # 5) 以上全都失败，安装 nvm + Node.js
  echo "[Info] Node.js not found, installing via nvm..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.8/install.sh | bash
  export NVM_DIR="${HOME}/.nvm"
  if [ -f "${NVM_DIR}/nvm.sh" ]; then
    . "${NVM_DIR}/nvm.sh"
  fi
  nvm install 22
  if command -v node > /dev/null 2>&1; then
    NODE="node"
    NPM="npm"
    echo "[Info] Node.js installed: $($NODE -v)"
    return 0
  fi

  echo "[Error] Cannot find or install Node.js"
  return 1
}

find_node || exit 1

echo "Node.js: $($NODE -v)"
echo "npm:      $($NPM -v)"
echo
echo "Installing dependencies..."
$NPM install --production --registry=https://registry.npmmirror.com

if [ $? -eq 0 ]; then
    echo
    echo "========================================"
    echo "  Installation Complete!"
    echo "========================================"
else
    echo "[Error] Installation failed."
fi
