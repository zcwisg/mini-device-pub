#!/bin/bash
echo "========================================"
echo "  UART NodeJS - Install Dependencies"
echo "========================================"
echo

# 检测可用的 Node.js：本地 > 全局 > 安装
find_node() {
  if [ -f "$(pwd)/node/bin/node" ]; then
    NODE="$(pwd)/node/bin/node"
    NPM="$(pwd)/node/bin/npm"
    echo "[Info] Using local bundled Node.js"
    return 0
  fi

  if command -v node > /dev/null 2>&1; then
    NODE="node"
    NPM="npm"
    echo "[Info] Using global Node.js"
    return 0
  fi

  echo "[Info] Node.js not found, installing via nvm..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.8/install.sh | bash
  . "$HOME/.nvm/nvm.sh"
  nvm install 22
  NODE="node"
  NPM="npm"
  echo "[Info] Node.js installed: $($NODE -v)"
  return 0
}

find_node

echo "Node.js: $($NODE -v)"
echo "npm:      $($NPM -v)"
echo
echo "Installing dependencies..."
$NPM install --production --registry=https://registry.npmmirror.com

if [ $? -eq 0 ]; then
    echo
    echo "========================================"
    echo "  Installation Complete!"
    echo "========================================"
else
    echo "[Error] Installation failed."
fi
