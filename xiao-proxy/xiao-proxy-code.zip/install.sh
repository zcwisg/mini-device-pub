#!/bin/bash
echo "========================================"
echo "  UART NodeJS - Install Dependencies"
echo "========================================"
echo

echo "Checking system dependencies (libudev for usb-detection)..."
if command -v apt-get &> /dev/null; then
    apt-get update -qq
    apt-get install -y -qq libudev-dev build-essential python3 2>/dev/null
elif command -v yum &> /dev/null; then
    yum install -y -q libudev-devel make gcc-c++ python3 2>/dev/null
elif command -v apk &> /dev/null; then
    apk add --no-cache eudev-dev make g++ python3 2>/dev/null
fi

echo "Installing dependencies..."
# Set PATH to use our bundled Node.js
export PATH="$(pwd)/node/bin:$PATH"
# Use bundled npm to install dependencies
node/bin/node node/lib/node_modules/npm/bin/npm-cli.js install --production

if [ $? -eq 0 ]; then
    echo
    echo "========================================"
    echo "  Installation Complete!"
    echo "========================================"
else
    echo "[Error] Installation failed."
fi
